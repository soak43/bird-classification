package birds;

public abstract class Animalia {
    abstract void displayCharacteristics();
}
